# Does More Enthusiasm from Language Teachers Always Help?

**Functional Form and Cross-Country Variation in Reading Achievement in PISA 2018**

## Overview

This repository contains supplementary materials for the study of the association between perceived language-teacher enthusiasm and student achievement using PISA 2018 data. The analysis examines the functional form of the association, uniform response patterns across the four enthusiasm items, within-school estimates, country-level variation, and an English-questionnaire-language subgroup.

## Repository contents

- `pisa_enthusiasm_analysis.R` — R script for data preparation, statistical analyses, and generation of tables and figures.
- `outputs/` — CSV result tables supplied with the supplementary materials.

### Supplied output tables

| File | Description |
|---|---|
| `01_pooled_models.csv` | Pooled model estimates |
| `02_interaction_uniform.csv` | Model estimates involving the uniform-response indicator and its interactions |
| `04_sumscore_means.csv` | Reading-score means by enthusiasm-item sum score and response type |
| `05_gam_aic.csv` | AIC comparisons of linear, quadratic, and spline models |
| `06_country_full.csv` | Country-level estimates using the full analytical sample |
| `06_country_mixed.csv` | Country-level estimates among mixed responders |
| `07_country_meta.csv` | Random-effects meta-analysis summaries |
| `08_english_subgroup.csv` | Models for the English-language questionnaire subgroup |
| `08b_english_interaction.csv` | Interaction estimates comparing English and other questionnaire-language groups |

Running the script also generates additional CSV files, figures, and `sessionInfo.txt` in `outputs/`. Those generated files are not all included in the supplied archive.

## Data

The analysis requires the PISA 2018 student questionnaire file `CY07_MSU_STU_QQQ.sav`, which is not included in this repository. Obtain the data from the [OECD PISA 2018 database](https://www.oecd.org/pisa/data/2018database/) and follow the OECD's applicable data-use conditions.

By default, the script expects `CY07_MSU_STU_QQQ.sav` in the working directory. If the file is stored elsewhere, edit the `SAV` path near the beginning of the script.

## Software and packages

The supplied analysis notes specify R 4.5.2. The script uses these R packages:

- `haven`
- `data.table`
- `mgcv`
- `metafor`
- `ggplot2`

Install any missing packages before running the script.

## Reproducing the analyses

1. Install R and the packages listed above.
2. Download `CY07_MSU_STU_QQQ.sav` from the OECD PISA 2018 database.
3. Place the data file in the working directory, or update `SAV` in the script.
4. Open `pisa_enthusiasm_analysis.R` in R or RStudio and run it from top to bottom.
5. The script writes its output to the `outputs/` directory.

The script sets the random seed to 2018. It also writes the R session information to `outputs/sessionInfo.txt` when it completes.

## Manuscript

**Title:** Does More Enthusiasm from Language Teachers Always Help? Functional Form and Cross-Country Variation in Reading Achievement in PISA 2018.

**Target journal:** *Sage Open*.

Please consult the associated manuscript for the full description of the research questions, measures, sample, and statistical methods.

## Citation

If you use these materials, please cite the associated manuscript. Full bibliographic details can be added here once the article has been accepted and published.
