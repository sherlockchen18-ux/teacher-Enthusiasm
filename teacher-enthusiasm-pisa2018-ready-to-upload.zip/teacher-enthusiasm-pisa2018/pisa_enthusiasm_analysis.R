# =====================================================================
# Perceived teacher enthusiasm and reading achievement, PISA 2018
# Functional form, uniform responders, schools, countries.
# One script, run top to bottom. Outputs go to ./outputs
# Needs: haven, data.table, mgcv, metafor, ggplot2
# Data: CY07_MSU_STU_QQQ.sav from https://www.oecd.org/pisa/data/2018database/
# =====================================================================
suppressPackageStartupMessages({library(haven);library(data.table);library(mgcv);library(metafor);library(ggplot2)})
SAV <- "CY07_MSU_STU_QQQ.sav"          # path to the student file
OUT <- "outputs"; dir.create(OUT, showWarnings = FALSE)
set.seed(2018)

# ---------------------------- 1. Read and filter ----------------------
items <- paste0("ST213Q0", 1:4, "HA")
pvr <- paste0("PV", 1:10, "READ"); pvm <- paste0("PV", 1:10, "MATH")
rw  <- paste0("W_FSTURWT", 1:80)
keep <- c("CNT","CNTSCHID","W_FSTUWT",rw,"TEACHINT","ESCS","ST004D01T","IMMIG","JOYREAD","LANGTEST_QQQ",items,pvr,pvm)
d <- as.data.table(read_sav(SAV, col_select = all_of(keep)))
d[, CNT := as.character(as_factor(CNT))]
d[, lang := as.character(as_factor(LANGTEST_QQQ))]   # language of the questionnaire / test
for (v in c("TEACHINT","ESCS","ST004D01T","IMMIG","JOYREAD",items,pvr,pvm,"W_FSTUWT")) d[, (v) := as.numeric(get(v))]

# units with at least 70% of students on the index; drop CAN, LBN, MKD (no index) and VNM (no reading scores)
cov <- d[, .(p = mean(!is.na(TEACHINT))), by = CNT]
ok  <- cov[p >= .70, CNT]; ok <- setdiff(ok, c("Canada","Lebanon","North Macedonia","Viet Nam","Vietnam"))
d <- d[CNT %in% ok]
d[, immig := fifelse(is.na(IMMIG), "Missing", paste0("I", IMMIG))]   # Japan has no IMMIG: separate category
d[, female := as.numeric(ST004D01T == 1)]
d <- d[!is.na(TEACHINT) & !is.na(ESCS) & !is.na(female) & !is.na(PV1READ) & !is.na(W_FSTUWT)]
d[, TI := TEACHINT]; d[, TI2 := TI^2]
d[, nmiss := rowSums(is.na(.SD)), .SDcols = items]
d[, U := fifelse(nmiss > 0, NA_real_, as.numeric(ST213Q01HA == ST213Q02HA & ST213Q02HA == ST213Q03HA & ST213Q03HA == ST213Q04HA))]
d[, sumscore := rowSums(.SD), .SDcols = items]
d[, g := as.integer(factor(CNT))]
d[, sg := as.integer(factor(paste(CNT, CNTSCHID)))]
Imm <- model.matrix(~ immig, d)[, -1, drop = FALSE]
cat("Students:", nrow(d), " Units:", uniqueN(d$CNT), "\n")
cat("Uniform:", sum(d$U == 1, na.rm = TRUE), " Mixed:", sum(d$U == 0, na.rm = TRUE), " Partial:", sum(is.na(d$U)), "\n")

# ---------------------------- 2. Estimator ----------------------------
# Weighted within-group demeaning (fixed effects), WLS, 80 BRR replicates (Fay 0.5, var = sum(dd')/20),
# all plausible values at once, pooled with Rubin's rules.
wdemean <- function(M, w, g) { g <- match(g, sort(unique(g))); s <- rowsum(M * w, g); sw <- rowsum(w, g); M - (s / as.vector(sw))[g, , drop = FALSE] }
wls <- function(X, Y, w, g) {
  Xd <- wdemean(X, w, g); Yd <- wdemean(Y, w, g)
  solve(crossprod(Xd * sqrt(w)), crossprod(Xd * w, Yd))          # k x P
}
fe_fit <- function(X, Y, W, RW, g) {
  b0 <- wls(X, Y, W, g)                                           # k x P (one column per plausible value)
  B  <- array(NA_real_, c(nrow(b0), ncol(b0), 80))
  for (r in 1:80) B[, , r] <- wls(X, Y, RW[[r]], g)
  samp <- apply(sweep(B, c(1, 2), b0)^2, c(1, 2), sum) / 20       # sampling variance per PV
  M <- ncol(b0); est <- rowMeans(b0)
  U <- rowMeans(samp); Bv <- if (M > 1) apply(b0, 1, var) else 0
  se <- sqrt(U + (1 + 1 / M) * Bv)
  z <- est / se; data.frame(term = colnames(X), b = est, se = se, z = z, p = 2 * pnorm(-abs(z)), row.names = NULL)
}
getRW <- function(dt) lapply(rw, function(v) dt[[v]])
fit <- function(dt, terms, Y, group = "g", extra = NULL) {
  X <- cbind(as.matrix(dt[, ..terms]), extra); fe_fit(X, as.matrix(dt[, ..Y]), dt$W_FSTUWT, getRW(dt), dt[[group]])
}
turn <- function(f) -f$b[f$term == "TI"] / (2 * f$b[f$term == "TI2"])
ctl <- c("ESCS","female")

# ---------------------------- 3. Pooled models (Table 1) --------------
res <- list()
mixed <- d[U == 0]; full <- d
Imm_f <- Imm; Imm_m <- Imm[which(d$U == 0), , drop = FALSE]
res$lin_full   <- fit(full,  c("TI", ctl), pvr, extra = Imm_f)
res$quad_full  <- fit(full,  c("TI","TI2", ctl), pvr, extra = Imm_f)
res$lin_mixed  <- fit(mixed, c("TI", ctl), pvr, extra = Imm_m)
res$quad_mixed <- fit(mixed, c("TI","TI2", ctl), pvr, extra = Imm_m)
res$quad_school<- fit(full,  c("TI","TI2", ctl), pvr, group = "sg", extra = Imm_f)
res$math_mixed <- fit(mixed, c("TI","TI2", ctl), pvm, extra = Imm_m)
jj <- mixed[!is.na(JOYREAD)]; Imm_j <- Imm[which(d$U == 0 & !is.na(d$JOYREAD)), , drop = FALSE]
res$joy_mixed  <- fit(jj, c("TI","TI2", ctl), "JOYREAD", extra = Imm_j)
for (n in names(res)) { cat("\n==", n, "==\n"); print(res[[n]]); if ("TI2" %in% res[[n]]$term) cat("turning point:", round(turn(res[[n]]), 2), "\n") }
fwrite(rbindlist(res, idcol = "model"), file.path(OUT, "01_pooled_models.csv"))

# ---------------------------- 4. Uniform responders -------------------
cc <- d[!is.na(U)]; Imm_c <- Imm[which(!is.na(d$U)), , drop = FALSE]
cc[, `:=`(TIU = TI * U, TI2U = TI2 * U)]
inter <- fit(cc, c("TI","TI2","U","TIU","TI2U", ctl), pvr, extra = Imm_c)
print(inter); fwrite(inter, file.path(OUT, "02_interaction_uniform.csv"))

# score gap by country (country-centred PV mean, weighted)
gap <- cc[, {
  y <- rowMeans(.SD); w <- W_FSTUWT
  .(gap = weighted.mean(y[U == 1], w[U == 1]) - weighted.mean(y[U == 0], w[U == 0]),
    share_uniform = weighted.mean(U, w), n = .N)}, by = CNT, .SDcols = pvr]
cat("Uniform lower in", sum(gap$gap < 0), "of", nrow(gap), "units; median gap", round(median(gap$gap), 1),
    "range", round(range(gap$gap), 1), "\n")
fwrite(gap, file.path(OUT, "03_uniform_gap_by_country.csv"))

# mean country-centred reading by sum score and response type (Figure 2)
d[, y1c := PV1READ - weighted.mean(PV1READ, W_FSTUWT), by = CNT]
sm <- d[!is.na(U), .(n = .N, mean_y = weighted.mean(y1c, W_FSTUWT)), by = .(sumscore, U)]
fwrite(sm, file.path(OUT, "04_sumscore_means.csv"))
ggsave(file.path(OUT, "Fig2_sumscore.png"),
  ggplot(d[!is.na(U), .(n = .N, y = weighted.mean(y1c, W_FSTUWT)), by = sumscore], aes(sumscore, y)) +
    geom_line() + geom_point(aes(size = n)) + theme_gray() +
    labs(x = "Sum of the 4 enthusiasm items", y = "Reading score, country-centred"), width = 5.3, height = 3.6, dpi = 300)

# ---------------------------- 5. Splines (GAM) ------------------------
# first plausible value, country-centred outcome and covariates, final weights
g1 <- copy(d[!is.na(U)])
for (v in c("PV1READ","ESCS")) g1[, (v) := get(v) - weighted.mean(get(v), W_FSTUWT), by = CNT]
g1[, imm_m := as.numeric(immig == "Missing")]
m_lin  <- bam(PV1READ ~ TI + ESCS + female + imm_m, data = g1, weights = W_FSTUWT)
m_quad <- bam(PV1READ ~ TI + I(TI^2) + ESCS + female + imm_m, data = g1, weights = W_FSTUWT)
m_spl  <- bam(PV1READ ~ s(TI, k = 6) + ESCS + female + imm_m, data = g1, weights = W_FSTUWT)
m_splU <- bam(PV1READ ~ s(TI, k = 6) + U + ESCS + female + imm_m, data = g1, weights = W_FSTUWT)
aic <- AIC(m_lin, m_quad, m_spl, m_splU); print(aic)
cat("AIC drop spline vs quad:", round(AIC(m_quad) - AIC(m_spl)), " vs linear:", round(AIC(m_lin) - AIC(m_spl)),
    " with U:", round(AIC(m_spl) - AIC(m_splU)), " extra edf:", round(sum(m_splU$edf) - sum(m_spl$edf), 1), "\n")
fwrite(as.data.table(aic, keep.rownames = "model"), file.path(OUT, "05_gam_aic.csv"))
png(file.path(OUT, "Fig3_spline_without_with_U.png"), 2000, 1100, res = 300)
par(mfrow = c(1, 2)); plot(m_spl, select = 1, main = "No group term", shade = FALSE, xlab = "TI"); plot(m_splU, select = 1, main = "With uniform-responder term", shade = FALSE, xlab = "TI"); dev.off()
# Figure 1: predictions at ESCS = 0
nd <- data.frame(TI = seq(min(g1$TI), max(g1$TI), length.out = 200), ESCS = 0, female = 0, imm_m = 0, U = 0)
pf <- rbind(data.frame(model = "linear", TI = nd$TI, fit = predict(m_lin, nd)), data.frame(model = "quadratic", TI = nd$TI, fit = predict(m_quad, nd)),
            data.frame(model = "gam", TI = nd$TI, fit = predict(m_spl, nd)))
ggsave(file.path(OUT, "Fig1_forms.png"), ggplot(pf, aes(TI, fit, linetype = model)) + geom_line() + theme_gray() +
  labs(x = "Teacher enthusiasm index (TEACHINT)", y = "Predicted reading score (PV1)"), width = 5.3, height = 3.6, dpi = 300)

# ---------------------------- 6. Country level ------------------------
country_fit <- function(dt, Y) {
  rbindlist(lapply(unique(dt$CNT), function(cn) {
    s <- dt[CNT == cn]; s[, one := 1L]
    f <- tryCatch(fit(s, c("TI","TI2","ESCS","female"), Y, group = "one"), error = function(e) NULL)
    if (is.null(f)) return(NULL)
    b1 <- f[f$term == "TI", ]; b2 <- f[f$term == "TI2", ]
    q <- quantile(s$TI, c(.05, .95)); tp <- -b1$b / (2 * b2$b)
    data.table(CNT = cn, n = nrow(s), b1 = b1$b, se1 = b1$se, p1 = b1$p, b2 = b2$b, se2 = b2$se, p2 = b2$p,
               tp = tp, inv_u = (b2$p < .05 & b2$b < 0 & b1$b > 0 & tp > q[1] & tp < q[2]))
  }))
}
cf_full  <- country_fit(full,  pvr); cf_mixed <- country_fit(mixed, pvr)
cf_mixed[, p2_bh := p.adjust(p2, "BH")]; cf_full[, p2_bh := p.adjust(p2, "BH")]
fwrite(cf_full, file.path(OUT, "06_country_full.csv")); fwrite(cf_mixed, file.path(OUT, "06_country_mixed.csv"))
summ <- function(cf, lab) {
  m1 <- rma(b1, sei = se1, data = cf, method = "REML"); m2 <- rma(b2, sei = se2, data = cf, method = "REML")
  data.table(sample = lab, units = nrow(cf),
    slope_pos = sum(cf$p1 < .05 & cf$b1 > 0), slope_neg = sum(cf$p1 < .05 & cf$b1 < 0),
    curv_neg = sum(cf$p2 < .05 & cf$b2 < 0), curv_pos = sum(cf$p2 < .05 & cf$b2 > 0), inv_u = sum(cf$inv_u),
    avg_slope = coef(m1), tau_slope = sqrt(m1$tau2), I2_slope = m1$I2,
    avg_curv = coef(m2), p_curv = m2$pval, tau_curv = sqrt(m2$tau2), I2_curv = m2$I2)
}
tab3 <- rbind(summ(cf_full, "all"), summ(cf_mixed, "mixed")); print(t(tab3)); fwrite(tab3, file.path(OUT, "07_country_meta.csv"))
cat("BH-significant negative curvature (mixed):", cf_mixed[p2_bh < .05 & b2 < 0, CNT], "\n")

# country-level link between curvature change and uniform responding
cmp <- merge(merge(cf_full[, .(CNT, b2_full = b2)], cf_mixed[, .(CNT, b2_mixed = b2)]), gap, by = "CNT")
cmp[, dcurv := b2_full - b2_mixed]
print(cor.test(cmp$dcurv, cmp$share_uniform, method = "spearman", exact = FALSE))
print(cor.test(cmp$dcurv, cmp$gap, method = "spearman", exact = FALSE))

# meta-regressions on country mean enthusiasm and mean reading
cm <- d[, .(mean_TI = weighted.mean(TI, W_FSTUWT), mean_read = weighted.mean(PV1READ, W_FSTUWT)), by = CNT]
cfm <- merge(cf_mixed, cm, by = "CNT")
for (mod in c("mean_TI","mean_read")) {
  print(rma(b2, sei = se2, mods = as.formula(paste("~", mod)), data = cfm, method = "REML"))
  print(rma(b1, sei = se1, mods = as.formula(paste("~", mod)), data = cfm, method = "REML"))
}

# four-country curves (Figure 4), observed range only, mixed responders
four <- c("Argentina","Switzerland","Indonesia","Kazakhstan")
pl <- rbindlist(lapply(four, function(cn) {
  s <- copy(mixed[CNT == cn]); s[, `:=`(y = PV1READ - weighted.mean(PV1READ, W_FSTUWT), ES = ESCS - weighted.mean(ESCS, W_FSTUWT))]
  m <- bam(y ~ s(TI, k = 6) + ES + female, data = s, weights = W_FSTUWT)
  nd <- data.frame(TI = seq(min(s$TI), max(s$TI), length.out = 100), ES = 0, female = 0)
  p <- predict(m, nd, se.fit = TRUE); data.table(CNT = cn, TI = nd$TI, fit = p$fit, lo = p$fit - 1.96 * p$se.fit, hi = p$fit + 1.96 * p$se.fit)
}))
ggsave(file.path(OUT, "Fig4_four_countries.png"), ggplot(pl, aes(TI, fit)) + geom_ribbon(aes(ymin = lo, ymax = hi), alpha = .3) + geom_line() +
  facet_wrap(~CNT, scales = "free_y") + theme_gray() + labs(x = "Teacher enthusiasm index", y = "Predicted reading score"), width = 5.6, height = 4.2, dpi = 300)
# ---------------------------- 7. English test-language students -------
# Needs sections 1 and 2 only (data, filters, helper functions). Sections 3 to 6 can be skipped.
cat("\nLanguage of the questionnaire, 15 most frequent:\n"); print(head(sort(table(d$lang), decreasing = TRUE), 15))
d[, E := as.numeric(grepl("^English", lang))]
cat("English-language students:", sum(d$E == 1), "\n"); print(d[E == 1, .N, by = CNT][order(-N)])
cat("Weighted share of uniform responders, English vs other:",
    round(d[!is.na(U) & E == 1, weighted.mean(U, W_FSTUWT)], 3), round(d[!is.na(U) & E == 0, weighted.mean(U, W_FSTUWT)], 3), "\n")
dropzero <- function(M) M[, apply(M, 2, function(z) any(z != 0)), drop = FALSE]
eng_full <- d[E == 1]; eng_mixed <- d[E == 1 & U == 0]
Imm_e  <- dropzero(Imm[which(d$E == 1), , drop = FALSE])
Imm_em <- dropzero(Imm[which(d$E == 1 & d$U == 0), , drop = FALSE])
res_en <- list(
  lin_full   = fit(eng_full,  c("TI", ctl), pvr, extra = Imm_e),
  quad_full  = fit(eng_full,  c("TI", "TI2", ctl), pvr, extra = Imm_e),
  lin_mixed  = fit(eng_mixed, c("TI", ctl), pvr, extra = Imm_em),
  quad_mixed = fit(eng_mixed, c("TI", "TI2", ctl), pvr, extra = Imm_em))
cat("N English, all / mixed:", nrow(eng_full), nrow(eng_mixed), "\n")
for (n in names(res_en)) { cat("\n== English,", n, "==\n"); print(res_en[[n]][1:2, ]); if ("TI2" %in% res_en[[n]]$term) cat("turning point:", round(turn(res_en[[n]]), 2), "\n") }
fwrite(rbindlist(res_en, idcol = "model"), file.path(OUT, "08_english_subgroup.csv"))
# Does the shape differ between English and other test languages? (mixed responders, country fixed effects)
mm <- d[U == 0]; mm[, `:=`(TIE = TI * E, TI2E = TI2 * E)]
Imm_mm <- dropzero(Imm[which(d$U == 0), , drop = FALSE])
int_en <- tryCatch(fit(mm, c("TI", "TI2", "E", "TIE", "TI2E", ctl), pvr, extra = Imm_mm), error = function(e) { message("interaction failed: ", conditionMessage(e)); NULL })
if (!is.null(int_en)) { print(int_en); fwrite(int_en, file.path(OUT, "08b_english_interaction.csv")) }
writeLines(capture.output(sessionInfo()), file.path(OUT, "sessionInfo.txt"))
cat("Done. Files in", OUT, "\n")
